@extends('master.public')
@section('title','  Search Businesses ')	

@section('seo')

    <meta name="description" content="Browse through various businesses from all over Lagos state and nigeria on 9jabusiness – the most popular social business directory in Nigeria."/>
    <meta name="keywords" content="Browse by businesses in Lagos and Nigeria" />
    <meta name="Robots" content="index,follow" />


@endsection

@section('top')	
		
		@include('components.search')
		<!--================================ SEARCH FORM==========================================-->
		
@endsection
@section('main')
		<div class="listing-section padding-bottom-20">
							<div class=""><!-- section container -->

								<div class="add-listing-wrapper">

								@if(isset($listings) )
									<div class="add-listing-nav shadow-1">
										<div class="row clearfix">
											<div class="col-md-12">
												{!! section_title(count($listings).' SEARCH RESULTS FOR <strong>'.htmlentities($query).'</strong>') !!}

											</div>
										</div>
									</div>

								@endif

									<div class="listing-main gridview padding-top-30 padding-bottom-30">
											<div id="latest-listing">
												<div class="listing-wrapper three-column row">
													<?php
													if(isset($listings) && count($listings) > 0)
													{

														small_listing($listings);
													}
													?>
												</div>
											</div>
											
									</div>

								

								</div>
							</div><!-- section container end -->
						</div>
@endsection

@section('sidebar')
	
	@include('components.top-categories')
	@include('components.ads')
	@include('components.top-locations')
							
@endsection